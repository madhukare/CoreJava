import java.util.Scanner;

public class Exponent {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int value1 = sc.nextInt();
		int value2 = sc.nextInt();
		System.out.println(calcExponent(value1, value2));
	}

	public static int calcExponent(int base, int number) {
		double exp = Math.log10(number) / Math.log10(base);
		if (Math.ceil(exp) == Math.floor(exp))
			return (int) exp;
		return -1;
	}

}
