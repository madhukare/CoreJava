import java.util.Scanner;

public class FahrenheitToCelsiusViceVersa {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double F = sc.nextDouble();
	    double C=sc.nextDouble();
		System.out.println("Fahrenheit to Celsius Degree is: " + FahrenheitToCelsius(F));
	    System.out.println("Celsius to Fahrenheit Degree is: "+CelsiusToFahrenheit(C));
	}

	public static double FahrenheitToCelsius(double F) {

		return (F - 32) * 5 / 9;

	}

	public static double CelsiusToFahrenheit(double C) {

		return ((C * 9) / 5) + 32;

	}

}
