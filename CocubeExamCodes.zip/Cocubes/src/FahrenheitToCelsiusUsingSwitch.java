import java.util.Scanner;

public class FahrenheitToCelsiusUsingSwitch {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double c = 100.0, f = 250.0;
		System.out.println("Enter your choice: ");
		int ch = sc.nextInt();
		switch (ch) {

		case 0:

			c = (f - 32) * 5 / 9;
			System.out.println("Fahrenheit to Celsius: " + c);
			break;

		case 1:

			f = ((9 * c) / 5) + 32;
			System.out.println("Celsius to Fahrenheit: " + f);
			break;

		default:
			System.out.println("please enter valid choice");
		}
	}

}
