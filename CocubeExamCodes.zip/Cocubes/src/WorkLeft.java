import java.util.Scanner;

public class WorkLeft {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int totalWork = sc.nextInt();
		int f1 = 20, f2 = 25, d1 = 10, d2 = 20;
		System.out.println(CalcRemainingWork(totalWork, f1, d1, f2, d2));

	}

	public static int CalcRemainingWork(int totalWork, int f1, int d1, int f2, int d2) {
		int RemainingWork = 0;
		RemainingWork = totalWork - ((f1 * d1) + (f2 * d2));
		return RemainingWork;

	}

}
