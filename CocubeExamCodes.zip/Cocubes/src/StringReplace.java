
public class StringReplace {

	public static void main(String[] args) {
		String str = "apple";
		System.out.println("Before Replacement: " + str);
		System.out.println("After Replacement: " + str.replace('a', 'P'));
		
	}

}
