import java.util.HashSet;
import java.util.Set;

public class SumOfOddElementsInArray {

	public static void main(String[] args) {
		int arr[] = { 1, 1, 2, 1, 3, 2, 3, 4, 4, 3, 4, 4, 6 };
		Set<Integer> Hset = new HashSet<Integer>();
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			int count = 0;
			for (int j = 0; j < arr.length; j++) {

				if (arr[i] == arr[j]) {

					count++;
				}

			}
			if (count % 2 != 0) {

				Hset.add(arr[i]);
			}
		}
		for (Integer k : Hset) {
			sum += k;
		}
		System.out.println(sum);
	}

}
