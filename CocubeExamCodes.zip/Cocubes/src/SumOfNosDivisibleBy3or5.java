import java.util.Scanner;

public class SumOfNosDivisibleBy3or5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		SumDivisibility(num);

	}

	public static void SumDivisibility(int num) {
		int sum = 0;
		for (int i = 1; i <= num; i++) {
			if (i % 3 == 0 || i % 5 == 0) {
				System.out.println("The numbers are: "+i);
				sum += i;
			}
		}
		System.out.println("Sum of Numbers that are divisible by 3 or 5 is : " + sum);
	}

}
