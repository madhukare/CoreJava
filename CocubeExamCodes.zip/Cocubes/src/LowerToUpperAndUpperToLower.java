
public class LowerToUpperAndUpperToLower {

	public static void main(String[] args) {
		String str = "This Is a SAMPLE text!";
		System.out.println(Conversion(str));
	}

	public static String Conversion(String str) {
		String result = "";
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if (Character.isUpperCase(ch)) {
				result += Character.toLowerCase(ch);
			} else
				result += Character.toUpperCase(ch);
		}
		return result;

	}

}
