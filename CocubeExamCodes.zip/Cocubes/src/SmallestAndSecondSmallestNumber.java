
public class SmallestAndSecondSmallestNumber {

	public static void main(String[] args) {
		int arr[] = { 5, 7, 9, 54, 1, 3 };
		sumArray(arr);
	}

	public static void sumArray(int arr[]) {
		int first, second, sum = 0;
		first = second = Integer.MAX_VALUE;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] < first) {
				second = first;
				first = arr[i];

			} else if (arr[i] != first && arr[i] < second) {
				second = arr[i];
			}
		}
		if (second == Integer.MAX_VALUE) {
			System.out.println("No second element is found");
		} else
			System.out.println("Smallest : " + first +"\nSecond Smallest : " + second);
		sum += first + second;
		System.out.println("Sum of Smallest and Second Smallest number in an array is : " + sum);
	}
}
