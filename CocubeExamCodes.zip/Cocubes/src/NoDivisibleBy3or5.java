import java.util.Scanner;

public class NoDivisibleBy3or5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		nodivisible(num);

	}

	public static void nodivisible(int num) {
		for (int i = 1; i <= num; i++) {
			if (i % 3 == 0 || i % 5 == 0) {
				System.out.println(i);
			}
		}
	}

}
