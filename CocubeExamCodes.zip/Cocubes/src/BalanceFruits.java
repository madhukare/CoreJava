
public class BalanceFruits {

	public static void main(String[] args) {
		int a = 8, m = 4, rs = 6;
		if (a > m) {
			rs = rs - (a - m);
			m = m + (a - m);
			
			System.out.println(a - m);
		} else if (a < m) {
			rs = rs + (m - a);
			m = m - (m - a);

		}
		System.out.println(a + " " + m + " " + rs);

	}

}
