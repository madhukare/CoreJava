import java.util.Scanner;

public class Temperature {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Fahrenheit temperature");
		double f = sc.nextDouble();
		double c = (f - 32) * 5 / 9;
		f = ((9 * c) / 5) + 32;
		System.out.println("Fahrenheit to celsius: " + c + " " + "Celsius to Fahrenheit: " + f);

	}

}
