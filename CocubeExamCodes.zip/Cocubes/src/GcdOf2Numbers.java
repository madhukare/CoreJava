
public class GcdOf2Numbers {

	public static void main(String[] args) {
		int n1 = 81, n2 = 153, gcd = 1;
		/*for (int i = 1; i <= n1 && i <= n2; i++) {
			if (n1 % i == 0 && n2 % i == 0) {
				gcd = i;
			}
		}
		System.out.println("G.C.D: "+gcd);*/
		/*n1 = (n1 > 0) ? n1 : -n1;
		n2 = (n2 > 0) ? n2 : -n2;//always set the given numbers to positive
		*/
		while (n1 != n2) {
			
			if (n1 > n2) {
				
				n1 -= n2;
			} 
			else
				n2 -= n1;
			
		}
		System.out.println("G.C.D : " + n1);
	}

}
