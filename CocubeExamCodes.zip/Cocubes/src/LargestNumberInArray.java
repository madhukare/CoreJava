
public class LargestNumberInArray {

	public static void main(String[] args) {
		int arr[] = { 7, 6, 4, 9, 1 };
		MaxArray(arr);
	}

	public static void MaxArray(int arr[]) {
		int Max = 0;
		for (int i = 0; i < arr.length; i++) {
			System.out.println("The elements in an array are:" + arr[i]);
			if (arr[i] > Max) {
				Max = arr[i];
			}
		}
		System.out.println("Max number in an array is:" + Max);
	}
}
