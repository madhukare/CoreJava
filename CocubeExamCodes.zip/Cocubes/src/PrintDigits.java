
public class PrintDigits {

	public static void main(String[] args) {
		String str = "a-b-c";
		System.out.println(Print(str));
	}

	public static String Print(String str) {
		String str1 = "", str2 = "";
		char ch;
		for (int i = 0; i < str.length(); i++) {
			ch = str.charAt(i);
			if (Character.isAlphabetic(ch)) {
				str1 += ch;
			} else
				str2 += ch;
		}
		return str2 + str1;
	}

}
