import java.util.Arrays;

public class MerArrayandSort {

	public static void main(String[] args) {
		System.out.println(arrMerg());

	}

	public static int arrMerg() {
		int arr[] = { 1, 2, 3, 3, 4, 5 };
		int arr1[] = { 1, 2, 2, 3, 4, 6 };
		int crr[] = new int[arr.length + arr1.length];
		for (int i = 0; i < arr.length; i++) {
			crr[i] = arr[i];
		}
		for (int i = 0; i < arr1.length; i++) {
			crr[i + arr.length] = arr1[i];
		}
		Arrays.sort(crr);
		return crr[crr.length / 2];

	}

}