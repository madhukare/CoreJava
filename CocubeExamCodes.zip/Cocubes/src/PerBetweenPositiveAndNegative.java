
public class PerBetweenPositiveAndNegative {

	public static void main(String[] args) {

		int arr[] = { 3, 2, 4, 5, 0, -1, -4, -67 };

		int countp = 0;
		int countn = 0;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] < 0)
				countn++;
			else
				countp++;
		}
		System.out.println("Positive Numbers: "+countp + "\nNegative Numbers: " + countn);
		float pofp = ((float) countp / arr.length) * 100;
		float pofn = ((float) countn / arr.length) * 100;
		System.out.println("Positive Percentage: "+pofp + "\nNegative Percentage: " + pofn);
		System.out.println("Difference : "+(pofp - pofn));
	}
}