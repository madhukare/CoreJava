import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class CountAlphabets {

	public static void main(String[] args) {

		String str = "abcdaabcaba";
		Map<Character, Integer> mp = new HashMap<Character, Integer>();
		int count = 0;
		int max = 0;
		char value = '\n';

		for (int i = 0; i < str.length(); i++) {

			char c = str.charAt(i);
			if (mp.containsKey(c)) {
				count = mp.get(c);
				mp.put(c, ++count);
			} else {
				mp.put(c, 1);
			}
			Set<Entry<Character, Integer>> entry = mp.entrySet();

			for (Entry<Character, Integer> e : entry)
				if (e.getValue() > max) {
					max = e.getValue();
					value = e.getKey();
				}

		}
		System.out.println(value + " " + max);

	}

}
