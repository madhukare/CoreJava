
public class NonRepeatingElements {
	
	public static void main(String args[]) {
		
		int arr[] = { 2, 4, 76, 3, 5, 2 };
		int brr[] = { 3, 7, 234, 7, 5 };
		int crr[] = new int[arr.length + brr.length];
		
		int totalcount = 0;
		for (int i = 0; i < arr.length; i++) {
			crr[i] = arr[i];
		}
		for (int i = 0; i < brr.length; i++) {
			crr[i + arr.length] = brr[i];
		}
		for (int i = 0; i < crr.length; i++) {
			int count = 0;
			for (int j = 0; j < crr.length; j++) {
				if (crr[i] == crr[j]) {
					count++;
				}

			}
			if (count == 1)
				totalcount++;

		}
		System.out.println(totalcount);
	}

}
