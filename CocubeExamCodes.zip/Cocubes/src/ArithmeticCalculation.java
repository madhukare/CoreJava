import java.util.Scanner;

public class ArithmeticCalculation {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a = 3, b = 4;
		System.out.println("Enter your choice: ");
		int ch = sc.nextInt();
		switch (ch) {
		case 1:
			System.out.println("Addition: " + (a + b));
			break;
		case 2:
			System.out.println("Subtraction: " + (a - b));
			break;
		case 3:
			System.out.println("Multiplication: " + (a * b));
			break;
		case 4:
			System.out.println("Division: " + (a / b));
			break;
		default:
			System.out.println("please enter a valid choice");
		}

	}
}
