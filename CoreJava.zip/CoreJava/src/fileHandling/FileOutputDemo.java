package fileHandling;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputDemo {

	public static void main(String[] args) throws IOException {
		
		FileOutputStream fos=null;
		
		try {
			String firstName="Sindhu";
			String lastName=" Malyala";
			//fos=new FileOutputStream("temp.txt");
			fos=new FileOutputStream("temp.txt",true);//append
			fos.write(firstName.getBytes());//converting string into byte array
		    fos.write(lastName.getBytes());
			
		} catch (FileNotFoundException e) {
			System.out.println(e);
			
			
		} catch (IOException e) {
			System.out.println(e);
			
			
			
		}finally{
			fos.close();
		}
		

	}

}
