package fileHandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;


public class FileInputDemo {

	public static void main(String[] args) throws IOException {

		FileInputStream fio = null;

		try {
			fio = new FileInputStream("Hello.txt");
			/*int i=fio.read();
			while (i !=-1){
				System.out.println((char) i);
				i=fio.read();
			}*/
			int i = 0;

			while ((i = fio.read()) != -1)
				System.out.print((char) i);

		} catch (FileNotFoundException e) {
			System.out.println(e);

		} catch (IOException e) {
			System.out.println(e);

		} finally {
			fio.close();
		}

	}

}
