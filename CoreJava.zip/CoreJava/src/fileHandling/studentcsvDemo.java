package fileHandling;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class studentcsvDemo {

	public static void main(String[] args) throws IOException {
	
		BufferedReader br=null;
		String line=null;
		List<studentcsv> csvlist=new ArrayList<>();
		
		try {
			br=new BufferedReader(new FileReader("student .csv"));
			while((line=br.readLine())!=null)
			{
				String arr[]=line.split(",");
				System.out.println(line);
				csvlist.add(new studentcsv(arr[0], Integer.parseInt(arr[1]), Integer.parseInt(arr[2]),Integer.parseInt(arr[3])));
			}
			Collections.sort(csvlist);
			for(studentcsv s:csvlist)
			{
				System.out.println(s);
			}
		} catch (FileNotFoundException e) {
			System.out.println(e);
		} catch (IOException e) {
			System.out.println(e);
		}finally{
			br.close();
		}
	}

}
