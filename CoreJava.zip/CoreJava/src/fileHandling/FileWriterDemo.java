package fileHandling;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriterDemo {

	public static void main(String[] args) throws IOException {

		FileWriter fw = null;

		try {
			String name = "sindhu";
			fw = new FileWriter("temp1.txt");
			fw.write(name);

		} catch (IOException e) {
			System.out.println(e);
			
			
		} finally {
			fw.close();
		}

	}

}
