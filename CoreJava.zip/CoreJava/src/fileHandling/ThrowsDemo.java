package fileHandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ThrowsDemo {

	public static void main(String[] args) {

		try {// rest of code will be executed if we use try & catch 
			test();
		} catch (FileNotFoundException e) {
			System.out.println(e);
		}

		System.out.println("REST OF CODE!!!");

	}

	public static void test() throws FileNotFoundException {

		FileInputStream fio = null;

		fio = new FileInputStream("Hello.txt");

	}

}
