package fileHandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ThrowsDemo1 {

	public static void main(String[] args) throws FileNotFoundException {// It will not execute rest of code
		test();
		System.out.println("Rest of code!!!");

	}

	public static void test() throws FileNotFoundException {
		FileInputStream fio = null;
		fio = new FileInputStream("Hello.txt");

	}
}
