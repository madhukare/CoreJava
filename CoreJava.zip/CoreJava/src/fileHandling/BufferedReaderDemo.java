package fileHandling;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BufferedReaderDemo {

	public static void main(String[] args) throws IOException {
		
		BufferedReader br = null;
		String line = null;
		List<Student> slist=new ArrayList<>();
		
		try {
			br = new BufferedReader(new FileReader("Student.txt"));
			while((line = br.readLine())!=null)
			{
				String arr[]=line.split(" ");
				/*for(int i=0;i<arr.length;i++)
					System.out.println(arr[i]);*/
				/*for(String i:arr)
					System.out.println(i);*/
				System.out.println(line);
				slist.add(new Student(Integer.parseInt(arr[0]), arr[1], Integer.parseInt(arr[2]), Integer.parseInt(arr[3]), Integer.parseInt(arr[3])));
				
				
			}
			Collections.sort(slist);
			for(Student s:slist)
			{
				System.out.println(s);
			}
			Collections.reverse(slist);
			System.out.println("Topper :"+slist.get(0));

		} catch (FileNotFoundException e) {

			System.out.println(e);

		} catch (IOException e) {
			System.out.println(e);
			
		}finally{
			br.close();
		}

	}

}
