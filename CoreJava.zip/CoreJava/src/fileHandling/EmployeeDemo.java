package fileHandling;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDemo {

	public static void main(String[] args) throws IOException {

		BufferedReader br = null;
		String line = null;
		List<Employee> elist = new ArrayList<>();

		try {
			br = new BufferedReader(new FileReader("Employee.txt"));
			while ((line = br.readLine()) != null) {

				String arr[] = line.split(" ");
				System.out.println(line);
				elist.add(new Employee(Integer.parseInt(arr[0]), arr[1], Integer.parseInt(arr[2]), arr[3]));
			}

			for (Employee e : elist) {

				if (e.getDesignation().equals("developer"))
					System.out.println(e);
			}

		} catch (FileNotFoundException e) {
			System.out.println(e);

		} catch (IOException e) {
			System.out.println(e);
		} finally {
			br.close();
		}

	}

}
