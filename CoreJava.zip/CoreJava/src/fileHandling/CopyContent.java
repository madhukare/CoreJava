package fileHandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyContent {

	public static void main(String[] args) throws IOException {
		
		FileInputStream fis=null;//FileReader fr=null;
		FileOutputStream fos=null;//FileWriter fw=null;
		
		try {
			fis=new FileInputStream("File1.txt");
			fos=new FileOutputStream("File2.txt");
			
			int i=0;
			
			while((i=fis.read())!=-1)
			{
				System.out.print((char)i);//it displays on the console
				fos.write(i);//copying content from file1 to fle2
			}
				

		} catch (FileNotFoundException e) {
			System.out.println(e);
			
		} catch (IOException e) {
			System.out.println(e);
			
		}finally{
			fis.close();
			fos.close();
		}
		
		
		 
	}

}
