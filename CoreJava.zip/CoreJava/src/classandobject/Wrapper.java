package classandobject;

public class Wrapper {

	public static void main(String[] args) {
	//autoboxing-Primitive to object
	int a=10;
	 Integer obj=new Integer(a);
	 System.out.println(obj);
	 //unboxing-object to primitive
	 a=obj;
	 //a=obj.intValue();
	 System.out.println(a);
	}

}
