package classandobject;

public class MobileDemo {

	public static void main(String[] args) {
		Mobile m1=new Mobile();
		m1.price=20000;
		m1.camera=16;
		m1.memory=64;
		m1.battery=3400;
		m1.ram=8;
		m1.brand="Redmi";
		m1.os="Android";
		m1.display=6;
		
		System.out.println("Price: "+m1.price);
		System.out.println("Camera: "+m1.camera);
		System.out.println("Memory: "+m1.memory);
		System.out.println("Battery: "+m1.battery);
		System.out.println("Ram: "+m1.ram);
		System.out.println("Brand: "+m1.brand);
		System.out.println("Os: "+m1.os);
		System.out.println("Display: "+m1.display);
		//m1.display();
		
		m1.makeCall();
		m1.receiveCall();
		m1.texting();
		
		System.out.println("------------------------------");
		Mobile m2=new Mobile();
		m2.display();
		m2.brand="Samsung";
		m2.price=15000;
		System.out.println("------------------------------");
		m2.display();

	}

}
