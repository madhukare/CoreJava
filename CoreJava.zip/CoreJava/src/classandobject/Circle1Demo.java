package classandobject;

public class Circle1Demo {

	public static void main(String[] args) {
		Circle1 c=new Circle1();
		c.setId(1);
		c.setRadius(3.5);
		c.display();
		System.out.println("---------------------");
		Circle1 c1=new Circle1(2, 6);
		c1.display();
	}

}
