package classandobject;

import java.util.Scanner;

public class Student1 {
	private int id;
	private String name;
	private String address;
	static String collegeName="BMS";
	static int idGenerator=1000;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	Student1()
	{
		
		this.id=++idGenerator;
		System.out.println("Default Constructor");
	}
	Student1(String name,String address){
		this.id=++idGenerator;
		this.name=name;
		this.address=address;
	}
	public void display()
	{
		System.out.println("id is: "+id);
		System.out.println("name is: "+name);
		System.out.println("address is: "+address);
		System.out.println("College Name: " +collegeName);
	}
	
	public void createStudent()
	{
		Scanner sc=new Scanner(System.in);
		/*System.out.println("Enter the id");
		this.id=sc.nextInt();*/
		System.out.println("Enter the name");
		this.name=sc.next();
		System.out.println("Enter the address");
		this.address=sc.next();
	}
}
