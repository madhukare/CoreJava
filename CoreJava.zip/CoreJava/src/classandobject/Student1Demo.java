package classandobject;

public class Student1Demo {

	public static void main(String[] args) {
		Student1  s= new Student1();
		s.createStudent();
		s.display();
		System.out.println("--------------------");
		Student1 s1=new Student1();
		//s1.setId(2);
		s1.setName("swetha");
		s1.setAddress("hyd");
		s1.display();
		System.out.println("-----------------------");
		
		Student1 s2=new Student1( "srinidhi", "hyd");
		//System.out.println("College Name "+Student1.collegeName);
		s2.display();

	}

}
