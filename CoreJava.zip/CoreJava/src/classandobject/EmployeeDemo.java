package classandobject;

public class EmployeeDemo {

	public static void main(String[] args) {
		Employee e1=new Employee("Sindhu", "Malyala", 20000);
		System.out.println("Annnual Salary :" +e1.getAnnualSalary());
		System.out.println("Raise Salary : "+e1.raiseSalary(10));
		System.out.println(e1);

	}

}
