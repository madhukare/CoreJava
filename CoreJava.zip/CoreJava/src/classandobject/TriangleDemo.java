package classandobject;

public class TriangleDemo {

	public static void main(String[] args) {
		Triangle t=new Triangle(12,10,20);
		t.areaOfTraingle();
		System.out.println(t);
		System.out.println("-------------------------------------");
		Triangle t1=new Triangle(6,8,9);
		t1.areaOfTraingle();
		System.out.println(t1);
		System.out.println("---------------------------------------");
		Triangle obj=Triangle.compare(t, t1);
		System.out.println("Greatest area is : " +obj.areaOfTraingle());

	}

}
