package classandobject;

public class Circle
{
		int id;
		double radius;
		

		public double area()
		{
			return 3.14*radius*radius;
		}
		public double Perimeter()
		{
			return 2*3.14*radius;
			
		}
		public void display()
		{
			System.out.println("Id is: "+id);
			System.out.println("Radius is: "+radius);
			System.out.println("Area of circle: "+area());
			System.out.println("Perimeter of circle: "+Perimeter());
			
		}
		
		
		
}