package classandobject;

public class RectangleAccessModifiersDemo {

	public static void main(String[] args) {
		
		RectangleAccessModifiers rec1=new RectangleAccessModifiers();
		rec1.setId(12);
		rec1.setLength(15);
		rec1.setWidth(12);
		rec1.display();
		System.out.println("-------------------------");
		
		RectangleAccessModifiers rec2=new RectangleAccessModifiers(1,15,18);
		rec2.display();
		System.out.println("------------------------------");
		RectangleAccessModifiers rec3=new RectangleAccessModifiers(2,13);
		rec3.display();

	}

}
