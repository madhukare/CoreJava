package classandobject;

public class RectangleDemo {

	public static void main(String[] args) {
		Rectangle r1=new Rectangle();
		r1.length=5;
		r1.breadth=7;
		r1.area();
		r1.perimeter();
		r1.display();

	}

}
