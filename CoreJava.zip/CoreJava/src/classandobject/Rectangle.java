package classandobject;

public class Rectangle {
	int length;
	int breadth;
	 
	
	public int area()
	{
		return length*breadth;
	}
	
	public int perimeter()
	{
		return 2*(length+breadth);
	}
	
	
	public void display()
	{
		System.out.println("Length is: "+length);
		System.out.println("Breadth is: "+breadth);
		System.out.println("Area is: "+area());
		System.out.println("Perimeter is: "+perimeter());
	}
}
