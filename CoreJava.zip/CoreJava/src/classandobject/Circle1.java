package classandobject;

public class Circle1 {
	private int id;
	private double radius;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getRadius() {
		return radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
	Circle1()
	{
		System.out.println("Default Constructor");
	}
	Circle1(int id, double radius)
	{
		this.id=id;
		this.radius=radius;
	}
	public void display()
	{
		System.out.println("id is : "+id);
		System.out.println("radius is: "+radius);
	}
}
