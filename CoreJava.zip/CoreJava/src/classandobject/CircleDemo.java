package classandobject;

public class CircleDemo {

	public static void main(String[] args) {
		Circle c1=new Circle();
		c1.id=1;
		c1.radius=3.5;
		c1.area();
		c1.Perimeter();
		c1.display();
	}

}
