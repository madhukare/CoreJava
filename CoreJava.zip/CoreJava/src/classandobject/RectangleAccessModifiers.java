package classandobject;

public class RectangleAccessModifiers {

	  private int id;
      private int length;
	  private int width;
	
	RectangleAccessModifiers()
	{
		System.out.println("Default Constructor");
	}
	RectangleAccessModifiers(int id, int length,int width)
	{
		
		this.id=id;
		this.length=length;
		this.width=width;
	}
	RectangleAccessModifiers(int id1,int length1)
	{
		id=id1;
		length=length1;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	
	public void display()
	{
		System.out.println("id is: "+id);
		System.out.println("length is: "+length);
		System.out.println("width is: "+width);
	}
}
	
