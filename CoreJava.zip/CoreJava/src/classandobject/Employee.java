package classandobject;

public class Employee {
	private int id;
	private String firstName;
	private String lastName;
	private String name;
	private int salary;
	static int idGenerator;

	public int getId() {
		return id;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getName() {
		return name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public Employee() {
		super();
	}

	public Employee(String firstName, String lastName, int salary) {
		this.id = ++idGenerator;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
	}

	public int getAnnualSalary() {
		return this.salary * 12;
	}

	public int raiseSalary(int Percent) {

		return this.salary + (this.salary * Percent / 100);

	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + firstName + lastName + ", salary=" + salary + "]";
	}

}
