package classandobject;

public class StudentDemo {

	public static void main(String[] args) {
		Student s1=new Student();
		s1.id=1;
		s1.name="Sindhu";
		s1.MobileNo=9010768696l;
		s1.emailId="sindhumalyala53@gmail.com";
		s1.address="Hyderabad";
		s1.display();
		

	}

}
