package classandobject;

public class Student {
	int id;
	String name;
	String emailId;
	long MobileNo;
	String address;
	public void display()
	{
		System.out.println("Id is: "+id);
		System.out.println("Name is: "+name);
		System.out.println("Email: "+emailId);
		System.out.println("Mobile: "+MobileNo);
		System.out.println("Address: "+address);
		
	}
}
