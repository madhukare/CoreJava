package classandobject;

public class RectangleUsingConstructor {
     int id;
     int length;
	 int width;
	
	RectangleUsingConstructor()
	{
		System.out.println("Default Constructor");
	}
	RectangleUsingConstructor(int id, int length,int width)
	{
		
		this.id=id;
		this.length=length;
		this.width=width;
	}
	RectangleUsingConstructor(int id1,int length1)
	{
		id=id1;
		length=length1;
	}
	
	
	public void display()
	{
		System.out.println("id is: "+id);
		System.out.println("length is: "+length);
		System.out.println("width is: "+width);
	}
}
