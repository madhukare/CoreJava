package classandobject;

public class Student2Demo {

	public static void main(String[] args) {
		Student2 s=new Student2("pravi",80,70,82);
		s.calcPercentage();
		System.out.println(s);
		Student2 s1=new Student2("prasu",80,70,60);
		s1.calcPercentage();
		System.out.println(s1);
		Student2 s2=new Student2("sindhu",75,80,85);
		s2.calcPercentage();
		System.out.println(s2);
		Student2 obj=Student2.compare(s, s1,s2);
		System.out.println("Highest Percentage "+obj);
	}

}
