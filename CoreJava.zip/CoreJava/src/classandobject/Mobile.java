package classandobject;

public class Mobile 
{
		double price;
		String brand;
		String os;
		int camera;
		int ram;
		int memory;
		float display;
		int battery;
		public void makeCall(){
			System.out.println("Dialing call...");
		}
		public void receiveCall()
		{
			System.out.println("Call Receiving....");
		}
		public void texting()
		{
			System.out.println("Texting....");
		}
		public void display()
		{
			System.out.println("Brand: "+brand);
			System.out.println("Price: "+price);
			System.out.println("Camera: "+camera);
			System.out.println("Memory: "+memory);
			System.out.println("Battery: "+battery);
			System.out.println("Ram: "+ram);
			System.out.println("Display: "+display);
			System.out.println("Os: "+os);
		}
}
