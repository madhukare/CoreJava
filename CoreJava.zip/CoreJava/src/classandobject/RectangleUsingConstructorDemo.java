package classandobject;

public class RectangleUsingConstructorDemo {

	public static void main(String[] args) {
		RectangleUsingConstructor rec1=new RectangleUsingConstructor();
		
		rec1.display();
		System.out.println("-----------------------------");
		RectangleUsingConstructor rec2=new RectangleUsingConstructor(1,15,18);
		rec2.display();
		System.out.println("------------------------------");
		RectangleUsingConstructor rec3=new RectangleUsingConstructor(2,13);
		rec3.display();
		
	}

}
