package Interface;

public class ShapeDemo {

	public static void main(String[] args) {
		Circle c=new Circle(12);
		System.out.println(c.toString());
		
		Circle c1=new Circle(20);
		System.out.println(c1);//we can declare without calling toString() also we will get same output by default
// if we don't declare toString() in a class then it will give output as packagename.classname@address
		
		
		Rectangle r=new Rectangle(6, 8);
		System.out.println(r);
	}

}
