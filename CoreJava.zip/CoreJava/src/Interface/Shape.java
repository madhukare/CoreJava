package Interface;

public interface Shape {
	public abstract double calcArea();//Declaration of abstract method in  older version
	public double calPerimeter();// Declaration of abstract method in latest version
	public static final double pi=3.14;

}
