package Interface;

public class Rectangle implements Shape {
	
	private int id;
	private int length;
	private int breadth;
	private static int idGenerator;
	
	
	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getBreadth() {
		return breadth;
	}

	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}

	public int getId() {
		return id;
	}

	public Rectangle() {
		super();
		this.id=++idGenerator;
	}

	public Rectangle(int length, int breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
		this.id=++idGenerator;
	}

	@Override
	public double calcArea() {
		
		return length*breadth;
	}

	@Override
	public double calPerimeter() {
		
		return 2*(length+breadth);
	}

	@Override
	public String toString() {
		return "Rectangle [id=" + id + ", length=" + length + ", breadth=" + breadth + ", calcArea()=" + calcArea()
				+ ", calPerimeter()=" + calPerimeter() + "]";
	}

}
