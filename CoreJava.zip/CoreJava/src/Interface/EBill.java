package Interface;

public class EBill implements Bill {
	private int numOfUnits;

	public int getNumOfUnits() {
		return numOfUnits;
	}

	public void setNumOfUnits(int numOfUnits) {
		this.numOfUnits = numOfUnits;
	}

	public EBill() {
		super();
	}

	public EBill(int numOfUnits) {
		super();
		this.numOfUnits = numOfUnits;
	}

	@Override
	public double calcBill() {

		return numOfUnits * perUnitCharge;
	}

	@Override
	public void displayBill() {
		System.out.println("No of units: " + numOfUnits);
		System.out.println("Charge per unit: " + perUnitCharge);
		System.out.println("Total Bill: " + calcBill());

	}

}
