package Interface;

public class Circle implements Shape {

	private int id;
	private double radius;
	public static int idGenerator = 1000;

	public int getId() {
		return id;

	}

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}

	public Circle() {
		super();
		this.id=++idGenerator;
	}

	public Circle(double radius) {
		super();
		this.radius = radius;
		this.id=++idGenerator;
	}

	@Override
	public double calcArea() {
		
		return pi*radius*radius;
	}

	@Override
	public double calPerimeter() {
		
		return 2*pi*radius;
	}

	@Override
	public String toString() {
		return "Circle [id=" + id + ", radius=" + radius + ", calcArea()=" + calcArea() + ", calPerimeter()="
				+ calPerimeter() + "]";
	}

	

}
