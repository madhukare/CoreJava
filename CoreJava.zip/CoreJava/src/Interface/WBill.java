package Interface;

public class WBill implements Bill {

	private int noOfLitres;

	public int getNoOfLitres() {
		return noOfLitres;
	}

	public void setNoOfLitres(int noOfLitres) {
		this.noOfLitres = noOfLitres;
	}

	public static int getPerLitreCharge() {
		return perLitreCharge;
	}

	public WBill() {
		super();
	}

	public WBill(int noOfLitres) {
		super();
		this.noOfLitres = noOfLitres;

	}

	@Override
	public double calcBill() {

		return noOfLitres * perLitreCharge;
	}

	@Override
	public void displayBill() {
		System.out.println("Amount of litres : " + noOfLitres);
		System.out.println("Charge per litre : " + perLitreCharge);
		System.out.println("Total Bill : " + calcBill());

	}

	
}
