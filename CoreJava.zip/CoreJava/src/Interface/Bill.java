package Interface;

public interface Bill {
	public double calcBill();

	public void displayBill();

	public static final int perLitreCharge = 15;
	
	public static final int perUnitCharge = 5;

}
