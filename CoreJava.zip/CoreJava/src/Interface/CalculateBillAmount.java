package Interface;

import java.util.Scanner;

public class CalculateBillAmount {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int ch = 0;

		int noOfLitres;
		int noOfUnits;

		while (true) {
			System.out.println("1.Water Bill");
			System.out.println("2.Electricity Bill");
			System.out.println("3. Exit");
			System.out.println("Enter your choice");
			ch = sc.nextInt();
			if (ch == 1) {
				System.out.println("Enter no. of litres");
				noOfLitres = sc.nextInt();
				WBill b1 = new WBill(noOfLitres);
				b1.displayBill();
			}

			else if (ch == 2) {
				System.out.println("Enter no of units");
				noOfUnits = sc.nextInt();
				EBill e1 = new EBill(noOfUnits);
				e1.displayBill();

			}

			else if (ch == 3) {
				System.exit(0);
			} else
				System.out.println("Invalid Choice");
		}
	}

}
