package userdefinedExceptions;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ProductDemo {

	public static void main(String[] args) {

		List<Product> plist = new ArrayList<>();

		plist.add(new Product(288.7, 45));
		plist.add(new Product(200, 30));
		plist.add(new Product(188.5, 50));
		plist.add(new Product(320, 100));
		plist.add(new Product(190, 200));
		plist.add(new Product(150.5, 150));
		plist.add(new Product(175.4, 90));
		plist.add(new Product(230, 250));
		plist.add(new Product(280, 300));
		plist.add(new Product(300, 400));

		Iterator<Product> itr = plist.iterator();
		while (itr.hasNext()) {

			try {
				Product p = itr.next();
				checkWeight(p);
			} catch (InvalidProductException e) {
				itr.remove();
				System.out.println(e);
			}
		}

	}

	public static void checkWeight(Product p) throws InvalidProductException {
		if (p.getWeight() < 200)
			throw new InvalidProductException("Invalid product");
		else
			System.out.println("Weight : " + p);
	}
}
