package userdefinedExceptions;

public class InvalidAgeException extends Exception {

	private static final long serialVersionUID = 1L;

	public InvalidAgeException(String s) {
		super(s);

	}

	public InvalidAgeException() {
		super();
	}
	// If there is no constructor in a class, then by default jvm will create constructors .
	// But if you give parameterized constructor,it will not generate default constructor, user has to give manually.

}
