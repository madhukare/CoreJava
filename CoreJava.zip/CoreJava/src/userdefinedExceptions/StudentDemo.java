package userdefinedExceptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class StudentDemo {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int rno = sc.nextInt();

		List<Student> slist = new ArrayList<>();
		slist.add(new Student("sindhu", 9010768696l, "hyd"));
		slist.add(new Student("nidhi", 8978187621l, "kkp"));
		slist.add(new Student("uday", 9877654321l, "gachibowli"));
		slist.add(new Student("swetha", 9988776655l, "hyd"));
		slist.add(new Student("pravallika", 7865467897l, "vizag"));
		slist.add(new Student("madhukar", 9875432109l, "kothapet"));
		
		Student temp=null;
		
		boolean flag = false;
		for (Student s : slist) {
			if (rno == s.getId()) {
				flag = true;
				temp=s;
				//System.out.println(s);
			} /* else
				  try { throw new
				  StudentNotFoundException("Student not found!!!"); } catch
				  (StudentNotFoundException e) {
				  System.out.println(e.getMessage()); // e.printStackTrace(); }
				 */
		}
		if(flag)
			System.out.println(temp);
		else
			try {
				throw new StudentNotFoundException("Student not found!!!");
			} catch (StudentNotFoundException e) {
				System.out.println(e.getMessage());
			}
			

	}

}
