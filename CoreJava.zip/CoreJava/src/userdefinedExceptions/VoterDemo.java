package userdefinedExceptions;

import java.util.ArrayList;
import java.util.List;

public class VoterDemo {

	public static void main(String[] args) {

		List<Voter> vlist = new ArrayList<>();

		vlist.add(new Voter("sindhu", "hyd", 9010768696l, 22));
		vlist.add(new Voter("nidhi", "hyd", 8978187621l, 22));
		vlist.add(new Voter("varsha", "lingampally", 9876543210l, 15));
		vlist.add(new Voter("swetha", "hyd", 9876542219l, 22));
		vlist.add(new Voter("pravallika", "hyd", 8765432108l, 21));

		for (Voter v : vlist)
			try {
				ageCheck(v);
			} catch (InvalidAgeException e) {
				System.out.println(e);
				//e.printStackTrace();
			}

	}

	public static void ageCheck(Voter v) throws InvalidAgeException {
		if (v.getAge() >= 18)
			System.out.println("Valid for Vote");

		else
			throw new InvalidAgeException("Invalid age for vote");

	}

}
