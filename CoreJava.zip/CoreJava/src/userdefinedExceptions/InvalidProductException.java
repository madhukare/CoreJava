package userdefinedExceptions;

public class InvalidProductException extends Exception {

	private static final long serialVersionUID = -6650398951988111745L;

	public InvalidProductException(String msg) {
		super(msg);
	}

	public InvalidProductException() {
		super();
	}
}
