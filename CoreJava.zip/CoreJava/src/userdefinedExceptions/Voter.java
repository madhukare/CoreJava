package userdefinedExceptions;

public class Voter {

	private int id;
	private String name;
	private String address;
	private long phone;
	private int age;
	static int idGenerator;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public int getId() {
		return id;
	}

	public static int getIdGenerator() {
		return idGenerator;
	}

	public Voter() {
		super();
		this.id=++idGenerator;
	}

	public Voter(String name, String address, long phone, int age) {
		super();
		this.id=++idGenerator;
		this.name = name;
		this.address = address;
		this.phone = phone;
		this.age = age;
	}

}
