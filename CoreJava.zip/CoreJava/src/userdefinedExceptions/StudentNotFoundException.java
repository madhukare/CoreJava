package userdefinedExceptions;

public class StudentNotFoundException extends Exception {

	private static final long serialVersionUID = -6585029031078999872L;

	public StudentNotFoundException(String s) {
		super(s);
	}

	public StudentNotFoundException() {
		super();
	}

}
