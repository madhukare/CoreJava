package userdefinedExceptions;

public class ThrowDemo {

	public static void main(String[] args)  {

		int age = 14;

		
			try {
				validate(age);
			} catch (ArithmeticException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
			}
		

	}

	public static void validate(int age) throws ArithmeticException {

		if (age >= 18)
			System.out.println("Valid age");

		else
			throw new ArithmeticException();

	}
}
