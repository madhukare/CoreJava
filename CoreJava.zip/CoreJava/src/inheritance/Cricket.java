package inheritance;

public class Cricket {

	public static void main(String[] args) {
		Batsman b1 = new Batsman("MS Dhoni", 350, 297, 10773, 12303, 84);
		System.out.println(b1);
		
		Bowler b = new Bowler("Jasprit Bumrah", 58,58, 103, 2254, 3009);
		System.out.println(b);
		
		
		//parent referring to child
		Player p3=new Batsman("Virat", 239, 230, 11520, 12359, 39);
		System.out.println(p3);
		
		
		System.out.println(b1.getName() + " Batsman average "+b1.calcAverage());
		
		System.out.println(p3.getName() + " Batsman average "+p3.calcAverage());

	}

}
