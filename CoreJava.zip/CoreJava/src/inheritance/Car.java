package inheritance;

public class Car extends Vehicle {

	private int numberOfSeats;
	private String color;
	private double price;

	public Car() {
		super();
	}

	public Car(String brand, String model, String registration, int numberOfSeats, String color, double price) {
		super(brand, model, registration);
		this.numberOfSeats = numberOfSeats;
		this.color = color;
		this.price = price;
	}

	public int getNumberOfSeats() {
		return numberOfSeats;
	}

	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Car [numberOfSeats=" + numberOfSeats + ", color=" + color + ", price=" + price + ", toString()="
				+ super.toString() + "]";
	}

}
