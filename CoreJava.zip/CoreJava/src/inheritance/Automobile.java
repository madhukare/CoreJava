package inheritance;

public class Automobile {

	public static void main(String[] args) {
		Bike b = new Bike("Pulsar", "220F", "TS 24 4987", 40, 90000, "black");
		System.out.println(b);

		Car c = new Car("Maruti", "Alto", "TS 19 269", 4, "Silver", 250000);
		System.out.println(c);

		Vehicle v=new Bike("KTM", "Duke 125", "TS 20 369", 34.5, 140000, "black");
		System.out.println(v);
		
		System.out.println(b.drive());

		System.out.println(v.followSafety());

	}

}
