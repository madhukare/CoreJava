package inheritance;

public class Vehicle {

	private String brand;
	private String model;
	private String registration;
	static int idGenerator;

	public Vehicle() {
		super();
	}

	public Vehicle(String brand, String model, String registration) {
		super();
		this.brand = brand;
		this.model = model;
		this.registration = registration;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getRegistration() {
		return registration;
	}

	public void setRegistration(String registration) {
		this.registration = registration;
	}

	public String followSafety() {
		
		return "follow safety rules";

	}

	public String  drive() {
		return "drive carefully";

	}

	@Override
	public String toString() {
		return "Vehicle [brand=" + brand + ", model=" + model + ", registration=" + registration + ", followSafety()="
				+ followSafety() + ", drive()=" + drive() + "]";
	}

}
