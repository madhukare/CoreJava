package inheritance;

public class Batsman extends Player {
	private int runsScored;
	private int ballsFaced;
	private int notOuts;

	public Batsman() {
		super();
	}

	public Batsman(String name, int matches, int innings, int runsScored, int ballsFaced, int notOuts) {
		super(name, matches, innings);
		this.runsScored = runsScored;
		this.ballsFaced = ballsFaced;
		this.notOuts = notOuts;
	}

	public int getRunsScored() {
		return runsScored;
	}

	public void setRunsScored(int runsScored) {
		this.runsScored = runsScored;
	}

	public int getBallsFaced() {
		return ballsFaced;
	}

	public void setBallsFaced(int ballsFaced) {
		this.ballsFaced = ballsFaced;
	}

	public int getNotOuts() {
		return notOuts;
	}

	public void setNotOuts(int notOuts) {
		this.notOuts = notOuts;
	}

	public double calcStrikeRate() {
		return ((runsScored * 100) / ballsFaced);
	}

	public double calcAverage() {
		return (double) runsScored / (super.getInnings() - notOuts);
	}

	@Override
	public String toString() {
		return "Batsman [runsScored=" + runsScored + ", ballsFaced=" + ballsFaced + ", notOuts=" + notOuts
				+ ", calcStrikeRate()=" + calcStrikeRate() + ", calcAverage()=" + calcAverage() + ", toString()="
				+ super.toString() + "]";
	}

}
