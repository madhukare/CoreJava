package inheritance;

public class Player {

	private int id;
	private String name;
	private int matches;
	private int innings;
	static int idGenerator;

	public Player() {
		super();
		this.id = ++idGenerator;
	}

	public Player(String name, int matches, int innings) {
		super();
		this.name = name;
		this.matches = matches;
		this.innings = innings;
		this.id = ++idGenerator;
	}

	public int getInnings() {
		return innings;
	}

	public void setInnings(int innings) {
		this.innings = innings;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMatches() {
		return matches;
	}

	public void setMatches(int matches) {
		this.matches = matches;
	}

	public int getId() {
		return id;
	}

	public double calcAverage() {
		System.out.println("calc Average....");
		return 0.0;

	}

	@Override
	public String toString() {
		return "Player [id=" + id + ", name=" + name + ", matches=" + matches + "]";
	}

}
