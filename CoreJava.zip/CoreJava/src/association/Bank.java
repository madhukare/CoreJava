package association;

public interface Bank {
	
	public double calcSI();

}
