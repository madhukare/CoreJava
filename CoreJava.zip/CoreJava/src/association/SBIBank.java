package association;

public class SBIBank implements Bank {

	private String branchName;
	private String branchNo;
	private String ifscCode;
	public static final int rateOfInterest = 2;
	private Customer customer;

	public SBIBank() {
		super();
	}

	public SBIBank(String branchName, String branchNo, String ifscCode, Customer customer) {
		super();
		this.branchName = branchName;
		this.branchNo = branchNo;
		this.ifscCode = ifscCode;

		this.customer = customer;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getBranchNo() {
		return branchNo;
	}

	public void setBranchNo(String branchNo) {
		this.branchNo = branchNo;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public static int getRateofinterest() {
		return rateOfInterest;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public double calcSI() {

		return (customer.getInvestment() * customer.getDuration() * rateOfInterest) / 100.0;
	}

	@Override
	public String toString() {
		return "SBIBank [branchName=" + branchName + ", branchNo=" + branchNo + ", ifscCode=" + ifscCode
				+ ", rateOfInterest=" + rateOfInterest + ", customer=" + customer + ", calcSI()=" + calcSI() + "]";
	}

}
