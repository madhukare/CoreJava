package association;

public class EmployeeDemo {

	public static void main(String[] args) {
		
		Address a = new Address(24, "sainagar", "Hyderabad", "Telangana", "India", 500001);
		
		Employee e = new Employee("sindhu", "sindhu123@gmail.com", 25000, 9876543210l, a);
		System.out.println(e);
		
		System.out.println("Id:" +e.getId() + " Name:" +e.getName() + " City:" +e.getAddress().getCity() + " Country:" +e.getAddress().getCountry());
		
		e.getAddress().setFlatNo(26);
		
		e.getAddress().setStreet("nagar");
		
		System.out.println(e);
		
	}

}
