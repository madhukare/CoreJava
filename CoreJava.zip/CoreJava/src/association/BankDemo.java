package association;

public class BankDemo {

	public static void main(String[] args) {

		Customer c = new Customer(9875432100l, "Sindhu", "Savings", 20000, 2.5f);

		SBIBank s = new SBIBank("Hyderabad", "SBI123", "SBI00001", c);
		System.out.println(s);

		ICICIBank i=new ICICIBank("hyderabad", "ICICI432", "ICICI0098",c);
		System.out.println(i);
		
		System.out.println("CustomerName:"+s.getCustomer().getAccHolderName() + " AccNo:"+s.getCustomer().getAccNo() + " BranchName:"+s.getBranchName() + " SI:"+s.calcSI());
	}

}
