package association;

public class Employee {
	private int id;
	private String name;
	private String emailId;
	private double salary;
	private long phoneNo;
	private Address address;
	static int idGenerator;

	public Employee() {
		super();
		this.id = ++idGenerator;
	}

	public Employee(String name, String emailId, double salary, long phoneNo, Address address) {
		super();
		this.id = ++idGenerator;
		this.name = name;
		this.emailId = emailId;
		this.salary = salary;
		this.phoneNo = phoneNo;
		this.address = address;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", emailId=" + emailId + ", salary=" + salary + ", phoneNo="
				+ phoneNo + ", address=" + address + "]";
	}

}
