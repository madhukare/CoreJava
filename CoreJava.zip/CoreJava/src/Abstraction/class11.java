package Abstraction;

public class class11 extends Student {

	private int English;
	private int Hindi;
	private int MathsT;
	private int PhysicsT;
	private int chemistryT;
	private int physicsP;
	private int chemistryP;
	private int mathsP;

	public class11() {
		super();

	}

	public class11(int english, int hindi, int mathsT, int physicsT, int chemistryT, int physicsP, int chemistryP,
			int mathsP) {
		super();
		English = english;
		Hindi = hindi;
		MathsT = mathsT;
		PhysicsT = physicsT;
		this.chemistryT = chemistryT;
		this.physicsP = physicsP;
		this.chemistryP = chemistryP;
		this.mathsP = mathsP;
	}

	public class11(String name, int english, int hindi, int mathsT, int physicsT, int chemistryT, int physicsP,
			int chemistryP, int mathsP) {
		super(name);
		English = english;
		Hindi = hindi;
		MathsT = mathsT;
		PhysicsT = physicsT;
		this.chemistryT = chemistryT;
		this.physicsP = physicsP;
		this.chemistryP = chemistryP;
		this.mathsP = mathsP;
	}

	public int getEnglish() {
		return English;
	}

	public void setEnglish(int english) {
		English = english;
	}

	public int getHindi() {
		return Hindi;
	}

	public void setHindi(int hindi) {
		Hindi = hindi;
	}

	public int getMathsT() {
		return MathsT;
	}

	public void setMathsT(int mathsT) {
		MathsT = mathsT;
	}

	public int getPhysicsT() {
		return PhysicsT;
	}

	public void setPhysicsT(int physicsT) {
		PhysicsT = physicsT;
	}

	public int getChemistryT() {
		return chemistryT;
	}

	public void setChemistryT(int chemistryT) {
		this.chemistryT = chemistryT;
	}

	public int getPhysicsP() {
		return physicsP;
	}

	public void setPhysicsP(int physicsP) {
		this.physicsP = physicsP;
	}

	public int getChemistryP() {
		return chemistryP;
	}

	public void setChemistryP(int chemistryP) {
		this.chemistryP = chemistryP;
	}

	public int getMathsP() {
		return mathsP;
	}

	public void setMathsP(int mathsP) {
		this.mathsP = mathsP;
	}

	public double percentOfPCMTheoryPrac() {
		return (((MathsT + PhysicsT + chemistryT) / 180.0) + (((mathsP + physicsP + chemistryP) / 120.0)) * 100);
	}

	public double percentOfEngHin() {
		return (((English + Hindi) / 200.0) * 100);
	}

	@Override
	public double findPercentage() {

		return (percentOfPCMTheoryPrac() + percentOfEngHin() / 500.0);
	}

	@Override
	public String toString() {
		return "class11 [English=" + English + ", Hindi=" + Hindi + ", MathsT=" + MathsT + ", PhysicsT=" + PhysicsT
				+ ", chemistryT=" + chemistryT + ", physicsP=" + physicsP + ", chemistryP=" + chemistryP + ", mathsP="
				+ mathsP + ", findPercentage()=" + findPercentage() + ", toString()=" + super.toString() + "]";
	}
}
