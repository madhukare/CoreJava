package Abstraction;

public abstract class Student {
	private int id;
	private String name;
	static int idGenerator;

	public Student() {
		super();
		this.id = ++idGenerator;
	}

	public Student(String name) {
		super();
		this.name = name;
		this.id = ++idGenerator;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public abstract double findPercentage();

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + "]";
	}

}
