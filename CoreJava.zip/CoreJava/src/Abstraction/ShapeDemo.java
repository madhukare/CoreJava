package Abstraction;

public class ShapeDemo {

	public static void main(String[] args) {

		Circle c = new Circle("black", true, 3.5);
		System.out.println(c);

		Rectangle r = new Rectangle("blue", true, 4.5, 2.3);
		System.out.println(r);

		Shape s = new Rectangle(4, 5);
		System.out.println(s);

	}

}
