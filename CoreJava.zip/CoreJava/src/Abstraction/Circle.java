package Abstraction;

public class Circle extends Shape {
	protected double radius;

	public static final double pi = 3.14;

	public Circle() {
		super();
	}

	public Circle(double radius) {
		super();
		this.radius = radius;
	}

	public Circle(String color, boolean filled, double radius) {
		super(color, filled);
		this.radius = radius;
	}

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}

	@Override
	public double getArea() {

		return pi * radius * radius;
	}

	@Override
	public double getPerimeter() {

		return 2 * pi * radius;
	}

	@Override
	public String toString() {
		return "Circle [radius=" + radius + ", getArea()=" + getArea() + ", getPerimeter()=" + getPerimeter()
				+ ", toString()=" + super.toString() + "]";
	}

}
