package Abstraction;

public class School {

	public static void main(String[] args) {

		class8 c8 = new class8("vaishu", 85, 75, 80, 96, 90);
		System.out.println(c8);

		class11 c11 = new class11("sindhu", 95, 90, 55, 56, 52, 35, 33, 38);
		System.out.println(c11);

		Student s = new class8("varsha", 90, 87, 85, 75, 98);
		System.out.println(s);

		System.out.println(c8.getName() + " Percentage : " + c8.findPercentage());

		System.out.println(c11.getName() + " Percentage : " + c11.findPercentage());

		System.out.println(s.getName() + " Percentage : " + s.findPercentage());
	}

}
