package exceptionHandling;

public class ExceptionDemo {

	public static void main(String[] args) {
		int a=10;
		int b=0;
		System.out.println(div(a,b));
		System.out.println("Rest of the code........");
		int sum=a+b;
		System.out.println(sum);
		
	}
	public static int div(int a, int b)
	{
		int res=0;
		try{
			
			res=a/b;
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return res;
	}
}
