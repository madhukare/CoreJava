package exceptionHandling;

public class MultipleCatchDemo {

	public static void main(String[] args) {
		int a[]=new int[5];
		String s=null;
		int len=0;
		try{
			len=s.length();//only one exception will occur
			a[5]=30/0;//it will check right hand side operator first & execute line 12
		}catch(ArithmeticException e){
			System.out.println(e);
		}catch(ArrayIndexOutOfBoundsException e){
			System.out.println(e);
		}catch(NullPointerException e){//only one catch block will be executed
			System.out.println(e);
		}catch(Exception e){//should be written at the end of all exceptions but it is optional
			System.out.println(e);
		}
		System.out.println("Rest of Code......");
		

	}

}
