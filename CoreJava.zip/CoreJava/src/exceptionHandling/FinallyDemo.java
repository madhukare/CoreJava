package exceptionHandling;

public class FinallyDemo {
	public static void main(String[] args) {
		String s = null;
		try {
			System.out.println(s.length());
		} catch (ArithmeticException e) {
			System.out.println(e);
		} catch (NullPointerException e) {
			System.out.println(e);
		} finally {// It will execute whether the exception occurs or not
			System.out.println("Finally Block");
		}
		System.out.println("Rest of code......");// It prints only when proper
													// catch is handled

	}
}
