package exceptionHandling;

public class NullException {

	public static void main(String[] args) {
		
		String s=null;
		System.out.println(exc(s));

	}
	public static String exc(String s)
	{
		String str="";
		try
		{
			s.length();
		}catch(Exception e)
		{
			//System.out.println(e.toString());-shows the exception name
			System.out.println(e);// shows the exception name
			//System.out.println(e.getMessage());-retrieve the message in variable(s)
			//e.printStackTrace();-shows the exception in detail using line numbers
		}
		return str;
	}

}
