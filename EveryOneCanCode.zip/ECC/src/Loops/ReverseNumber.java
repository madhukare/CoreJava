package Loops;

public class ReverseNumber {

	public static void main(String[] args) {
	   int num=154;
	   int digit=0,rev = 0;
	   System.out.println(num);
	   while(num != 0)
	   {
		   digit=num%10;
		   rev=(rev*10)+digit;
		   num=num/10;
	   }
	   
	   System.out.println(rev);
	}

}
