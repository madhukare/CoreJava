package Loops;

import java.util.Scanner;

public class Armstrong {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		armstrong(num);

	}
	public static void armstrong(int num){
		int digit=0,sum=0,temp;
		temp=num;
		while(num>0){
			digit=num%10;
			sum+=digit*digit*digit;
			num=num/10;
		}
		if(temp==sum){
			System.out.println("armstrong");
		}else{
			System.out.println("not an armstrong");
		}
	}

}
