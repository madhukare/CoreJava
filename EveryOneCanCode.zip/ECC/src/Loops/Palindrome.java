package Loops;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		 boolean result= palindrome(num);
		 if(result==true)
			 System.out.println("palindrome");
		else
			 System.out.println("not palindrome");

	}
	public static boolean palindrome(int num){
		int digit=0,rev=0,temp;
		temp=num;
		while(num>0){
			digit=num%10;
			rev=rev*10+digit;
			num=num/10;
		}
		System.out.println(rev);
		if(rev==temp){
			return true;
		}
		else{
			return false;
		}
	}
}
