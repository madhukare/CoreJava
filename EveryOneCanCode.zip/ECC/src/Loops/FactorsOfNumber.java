package Loops;

import java.util.Scanner;

public class FactorsOfNumber{

	public static void main(String[] args) {
		int num;
		Scanner sc=new Scanner(System.in);
		num=sc.nextInt();
		factors(num);
	}
	public static void factors(int n)
	{
		for(int i=1;i<=n;i++)
		{
			if(n%i==0)
			{
			   System.out.println(i);
			}
		}
		
	}

}
