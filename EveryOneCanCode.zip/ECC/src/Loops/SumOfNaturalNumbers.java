package Loops;

import java.util.Scanner;

public class SumOfNaturalNumbers {

	public static void main(String[] args) {
		int num;
		Scanner sc=new Scanner(System.in);
		num=sc.nextInt();
		System.out.println(SumOfNatural(num));
	}
	public static int SumOfNatural(int n)
	{
		int sum=0;
		
		for(int i=1;i<=n;i++)
			sum=sum+i;
		
		return sum;
	}

}
