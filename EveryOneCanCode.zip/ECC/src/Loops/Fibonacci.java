package Loops;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		fibseries(num);

	}
	 public static void fibseries(int num)
	 {
		 int f1=0,f2=1,sum=0;
		 for(int i=1;i<=num;i++)
		 {
			 System.out.println(f1);
			 sum=f1+f2;
			 f1=f2;
			 f2=sum;
		 }
		 
	 }
}
