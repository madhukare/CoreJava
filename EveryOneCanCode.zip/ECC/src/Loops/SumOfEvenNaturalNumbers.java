package Loops;

import java.util.Scanner;

public class SumOfEvenNaturalNumbers {

	public static void main(String[] args) 
	{
		int num=0,sum=0;
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		while(num <= n)
		{
			sum+=num;
			num+=2;
			
		}
		System.out.println(sum);
	}

}
