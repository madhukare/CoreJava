package Loops;

import java.util.Scanner;

public class RangeOfPrimeNumbers {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num1=sc.nextInt();
		int num2=sc.nextInt();
		PrintPrime(num1,num2);

	}
	public static void PrintPrime(int num1,int num2)
	{
		for(int i=num1;i<=num2;i++)
		{
			int count=0;
			for(int j=num1;j<num2;j++)
			{
				if(i%j==0)
				{
				  count++;
				}
			}
			if(count==1)
			{
				System.out.println(i);
			}
		}
		
	}
}
