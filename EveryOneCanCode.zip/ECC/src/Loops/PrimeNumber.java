package Loops;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		int num=sc.nextInt();
		boolean result=isPrime(num);
		if(result==true)
		  System.out.println("Prime Number");
		else
			System.out.println("Non-prime Number");
	}
	public static boolean isPrime(int n)
	{
		int count=0;
		//int flag=0;
		for(int i=2;i<=n/2;i++)
		{
			if(n%i==0)
				//flag=1;
				//break;
				count++;
		}
		if(count==0)
		//if(flag==0)
		   return true;
		else
			return false;
	}

}
