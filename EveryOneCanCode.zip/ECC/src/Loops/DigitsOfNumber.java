package Loops;

import java.util.Scanner;

public class DigitsOfNumber {

	public static void main(String[] args) {
		int num,digit=0;
		Scanner sc=new Scanner(System.in);
		num=sc.nextInt();
		while(num > 0)
		{
			digit=num%10;
			System.out.print(digit);
			num=num/10;
		}
	}

}
