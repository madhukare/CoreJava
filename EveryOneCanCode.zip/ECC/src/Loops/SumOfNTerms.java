package Loops;

import java.util.Scanner;

public class SumOfNTerms {

	public static void main(String[] args) {
		int i=1,sum=0;
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		while(i <= n)
		{
			sum+=i;
			i++;
		}
		System.out.println(sum);
	}

}
