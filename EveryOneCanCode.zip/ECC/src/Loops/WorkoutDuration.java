package Loops;

import java.util.Scanner;

public class WorkoutDuration {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter 3 values");
		int n1=sc.nextInt();
		int n2=sc.nextInt();
		int n3=sc.nextInt();
		System.out.println("enter a number");
		int n=sc.nextInt();
		CalcSum(n1,n2,n3,n);

	}
    public static void CalcSum(int n1, int n2,int n3,int n)
    {
    	int sum=0;
    	
    	for(int i=4;i<=n;i++)
    	{
    		sum=n1+n2+n3;
    		n1=n2;
    		n2=n3;
    		n3=sum;
    		
    	}
    	System.out.println("total sum is : "+sum);
    }
}
