package Loops;

import java.util.Scanner;

public class RangeInPalindrome {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int start = sc.nextInt();
		int end = sc.nextInt();
		PrintPalindrome(start, end);
	}

	public static void PrintPalindrome(int start, int end) {
		int num;

		for (int i = start; i <= end; i++) {
			num = i;
			int rev = 0;
			while (num > 0) {
				int digit = num % 10;
				rev = (rev * 10) + digit;
				num = num / 10;
			}
			if (rev == i)
				System.out.println(i);
		}

	}
}
