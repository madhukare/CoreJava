package Loops;

public class Combinations {

	public static void main(String[] args) {
		
	    	for(int apples=1;apples<=100;apples++)
			{
				for(int bananas=1;bananas<=100;bananas++)
				{
					for(int oranges=1;oranges<=100;oranges++)
						if(apples+bananas+oranges==100)
						{
							if(((apples*5)+(bananas*0.5)+(oranges*1))==100)
							{
								System.out.println(apples+" "+bananas+" "+oranges);
							}
							
						}
				}
			}

	}
}
