package Loops;

import java.util.Scanner;

public class MaxDigitNumber {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		SecondMax(num);
		
	}
	public static void SecondMax(int num)
	{
		int digit=0,max1=0,max2=0;
		while(num > 0)
		{
		 digit=num%10;
		 if(max1<digit)
		 {
			 max2=max1;
			 max1=digit;
		 }
		 else if(max2<digit && max1!=digit)
		 {
			 max2=digit;
		 }
		 num=num/10;
		}
		System.out.println("Max1 : "+max1);
		System.out.println("Max2 : "+max2);
	}

}
