package Loops;

import java.util.Scanner;

public class SumOfNosDivBy3or5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		result(num);
	}

	public static void result(int num) {
		int sum = 0;
		// System.out.println("The numbers which are divisible by 3 and 5
		// are:");
		for (int i = 1; i <= num; i++) {
			if (i % 3 == 0 || i % 5 == 0) {
				sum = sum + i;
				System.out.println(i);
			}
		}
		System.out.println("Sum of numbers which are divisible by 3 and 5 are : " + sum);
	}
}
