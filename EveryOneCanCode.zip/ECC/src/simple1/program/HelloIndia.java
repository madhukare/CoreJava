package simple1.program;

public class HelloIndia {
	public static void main(String[] args) {
		System.out.println("Hello India");

	}

}
