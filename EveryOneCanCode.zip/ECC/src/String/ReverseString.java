package String;

public class ReverseString {

	public static void main(String[] args) {
		String str = "";
		String str1 = new String("Hello");
		for (int i = str1.length() - 1; i >= 0; i--) {
			str = str + str1.charAt(i);
		}

		System.out.print(str);

	}

}
