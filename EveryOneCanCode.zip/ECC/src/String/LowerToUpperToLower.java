package String;

public class LowerToUpperToLower {

	public static void main(String[] args) {
		String str = "This Is a SAMPLE text!";
		System.out.println(convert(str));
	}

	public static String convert(String str) {
		char ch;
		String result = "";
		for (int i = 0; i < str.length(); i++) {
			ch = str.charAt(i);
			if (Character.isUpperCase(ch))
				result += Character.toLowerCase(ch);
			else
				result += Character.toUpperCase(ch);
		}
		return result;
	}

}
