package String;

public class ReverseWord {

	public static void main(String[] args) {
		String str = "talent sprint";
		String str1 = "";
		String rev = "";
		String[] arr = str.split(" ");
		for (int i = 0; i < arr.length; i++) {
			str1 = arr[i];
			System.out.println(str1);
			for (int j = str1.length() - 1; j >= 0; j--) {

				rev += str1.charAt(j);
			}
			rev += " ";

		}
		System.out.println(rev);
	}

}
