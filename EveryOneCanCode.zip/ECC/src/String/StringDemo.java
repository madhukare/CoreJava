package String;

public class StringDemo {

	public static void main(String[] args) {
		String str1="Hello World";
		String str2=new String("Hello World");
		System.out.println(str1.length());
		int len=str1.length();
		System.out.println("the length is: "+len);
		System.out.println(str1.charAt(0));
		System.out.println(str1.indexOf('H'));
		System.out.println(str1.lastIndexOf('o'));
		System.out.println(str1.substring(6));
		System.out.println(str1.substring(0,5));
		String name="Amar Akbar Anthony";
		int index1=name.indexOf(" ");
		int index2=name.lastIndexOf(" ");
		System.out.println("First Name: "+name.substring(0, index1));
		System.out.println("Middle Name: "+name.substring(index1+1,index2));
		System.out.println("Last Name: "+name.substring(index2+1));
		String str="Welcome to talent sprint";
		String arr[]=str.split(" ");
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		
		
	}

}
