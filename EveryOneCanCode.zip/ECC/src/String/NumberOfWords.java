package String;

public class NumberOfWords {

	public static void main(String[] args) {
		// int count=0;
		String str = "Psr Prime Tower Gachibowli";
		String arr[] = str.split(" ");
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
			// count++;
		}

		System.out.println(arr.length);
	}

}
