package Patterns;

public class PrintStarsNTo1 {

	public static void main(String[] args) {
		for(int i=1;i<=5;i++)//for(int i=5;i>=1;i--)
		{
			for(int k=1;k<i;k++)//for(int k=1;k<=5-i;k++)
			{
				System.out.print(" ");
			}
			for(int j=5;j>=i;j--)//for(int j=1;j<=i;j++)
			 
			{
				System.out.print("*");
			}
			System.out.println();
		}

	}

}
