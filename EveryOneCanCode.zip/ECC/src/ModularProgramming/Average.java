package ModularProgramming;

import java.util.Scanner;

public class Average {

	public static void main(String[] args) {
		int num1,num2,num3;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter 3 numbers");
		num1=sc.nextInt();
		num2=sc.nextInt();
		num3=sc.nextInt();
		double result= average(num1,num2,num3);
		System.out.println("average of 3 numbers is:"+result);

	}
	public static double average(double a,double b,double c){
		return (a+b+c)/3;
	}

}
