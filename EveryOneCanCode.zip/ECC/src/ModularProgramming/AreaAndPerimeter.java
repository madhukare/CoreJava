package ModularProgramming;

import java.util.Scanner;

public class AreaAndPerimeter {

	public static void main(String[] args) {
		double radius;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter radius");
		radius=sc.nextDouble();
		double result=area(radius);
		System.out.println("Area of circle is :" +result);
		double result1=perimeter(radius);
		System.out.println("Perimeter of circle is :"+result1);
		
	}
	public static  double area (double r ){
		return 3.14*r*r;
		
	}
	public static double perimeter(double r){
		return 2*3.14*r;
	}
}
