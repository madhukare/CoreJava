package ModularProgramming;

import java.util.Scanner;

public class SpeedCalculation {

	public static void main(String[] args) {
		int distance,hours,minutes,seconds;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter distance,hours,minutes,seconds");
		distance=sc.nextInt();
		hours=sc.nextInt();
		minutes=sc.nextInt();
		seconds=sc.nextInt();
		int result=conversion(hours,minutes,seconds);
		System.out.println("Time converted is: "+result);
		double speed=speedinmps(distance,result);
		System.out.println("Speed in mts per second is: "+speed);
		double speed1=speedinkph(distance,result);
		System.out.println("Speed in kms per hour is: "+speed1);
		double speed2=speedinmph(speed1);
		System.out.println("Speed in miles per hour is: "+speed2);
	}
	public static int conversion(int hrs,int min,int sec)
	{
		
		 return ((hrs*60*60)+(min*60)+sec);
		
	}
	public static double speedinmps(double d,double result)
	{
		
		return d/result;
		
	}
	public static double speedinkph(double d,double result)
	{
		return (d/1000)*(3600/result);
	}
	public static double speedinmph(double speed1)
	{
		return speed1*1000/1609;
	}
}
