package ModularProgramming;

import java.util.Scanner;

public class ArithmeticOperations {

	public static void main(String[] args) {
		int num1,num2;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter numbers");
		num1=sc.nextInt();
		num2=sc.nextInt();
		int result=add(num1,num2);
		/*int result1=sub(num1,num2);*/
		int result2=mul(num1,num2);
		//int result3=div(num1,num2);//
		System.out.println("Sum of numbers is " +result);
		System.out.println("Sub of numbers is " +sub(num1,num2));
		System.out.println("mul of numbers is " +result2);
		/*System.out.println("div of numbers is " +result3);*/
		div(num1,num2);
	}
	
	public static int add(int a,int b) {
		return a+b;
		
	}
	public static int sub(int a,int b){
		return a-b;
	}
	public static int mul(int a, int b){
		return a*b;
	}
	public static void div(int a, int b){	
		int result= a/b;
		System.out.println("div of numbers is " +result);
	}
}
