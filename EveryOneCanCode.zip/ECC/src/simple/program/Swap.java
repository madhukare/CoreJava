package simple.program;

import java.util.Scanner;

public class Swap {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		int num1,num2,swap;
		System.out.println("Enter 2 numbers");
		num1=sc.nextInt();
		num2=sc.nextInt();
		System.out.println("Before Swapping");
		System.out.println("num1: "+num1+ "\n" +"num2: "+num2);
		swap=num1;
		num1=num2;
		num2=swap;
		System.out.println("After Swapping");
		System.out.println("num1: "+num1+ "\n" +"num2: "+num2);
		

	}

}
