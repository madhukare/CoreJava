package simple.program;

import java.util.Scanner;

public class BodyOfMassIndex {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double weight, height, bmi;
		// System.out.println("enter weight");
		weight = sc.nextDouble();
		// System.out.println("enter height");
		height = sc.nextDouble();
		height = height / 100;
		bmi = weight / (height * height);
		System.out.println("BMI : " + bmi);
	}

}
