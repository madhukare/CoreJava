package simple.program;

import java.util.Scanner;

public class ArithmeticOperations {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 2 numbers");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		int add = num1 + num2;
		int sub = num1 - num2;
		int mul = num1 * num2;
		int div = num1 / num2;
		System.out.println("Addition of 2 numbers is " + add);
		System.out.println("subtraction of 2 numbers is " + sub);
		System.out.println("Multiplication of 2 numbers is " + mul);
		System.out.println("Division of 2 numbers is " + div);

	}

}
