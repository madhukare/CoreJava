package simple.program;

import java.util.Scanner;

public class SumAndDifference {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num,add,sub,unit,tens;
		System.out.println("enter a number");
		num=sc.nextInt();
		unit=num%10;
		tens=num/10;
		add=unit+tens;
		sub=unit-tens;
		System.out.println("Addition: "+add);
		System.out.println("Subtraction: "+sub);
		}
		
	}


