package simple.program;

import java.util.Scanner;

public class MinToYears {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int min = sc.nextInt();
		int yearsInMin = 24 * 60 * 365;
		int years = min / yearsInMin;
		int rem = min % yearsInMin;
		int days = rem / (24 * 60);
		rem = rem % (24 * 60);
		int hour = rem / 60;
		int mins = rem % 60;
		System.out.println("Given minutes has " + years + " years " + days + " days " + hour + " hours and " + mins + " minutes");

	}
}
