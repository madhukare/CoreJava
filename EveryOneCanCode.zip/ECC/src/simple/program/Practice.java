package simple.program;

public class Practice {

	public static void main(String[] args) {
		System.out.println("Welcome to Talent Sprint!!!\n\tPrime Tower\n\t\"Gachibowli\"");
		

	}

}
