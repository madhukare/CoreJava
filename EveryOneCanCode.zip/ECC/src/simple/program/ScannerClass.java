package simple.program;

import java.util.Scanner;

public class ScannerClass{

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter some number");
		int num=sc.nextInt();
		System.out.println("Entered value is");
		System.out.print(num);
		System.out.println("\nEnter some boolean");
		boolean b=sc.nextBoolean();
		System.out.println("Entered value is: " + b);
		sc.nextLine();
		System.out.println("\nEnter string");
		String s=sc.nextLine();
		System.out.println("Entered string is: " + s);
		System.out.println("\nEnter number");
		double d=sc.nextDouble();
		System.out.println("Entered number is: " + d);
	
	}

}
