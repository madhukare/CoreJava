package simple.program;

public class Variable {

	public static void main(String[] args) {
		long phone;
		float temp;
		String name;
		char ch;
		phone= 9010768696l;
		temp=36.5f;
		name= "sindhu";
		ch='x';
		System.out.println("Name : "+name +"\nMobile no: "+phone  +"\nTemperature: " +temp +"\nCharacter: "+ch);
	}

}
