package simple.program;

import java.util.Scanner;

public class MetersToInches {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		double inches,meters;
		System.out.println("enter the value:");
		inches=sc.nextDouble();
		meters=inches*0.0254;
		System.out.println("Inches = "+inches+"\nMeters = "+meters);
	}

}
