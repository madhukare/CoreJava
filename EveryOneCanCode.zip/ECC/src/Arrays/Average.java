package Arrays;

import java.util.Scanner;

public class Average {

	public static void main(String[] args) {
		int size;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size");
		size=sc.nextInt();
		int arr[]=new int[size];
		System.out.println("Enter the element");
		for(int i=0;i<size;i++)
			arr[i]=sc.nextInt();
		System.out.println("Average: " +calcAverage(arr));

	}
	public static int calcAverage(int arr[])
	{
		int sum=0;
		for(int i=0;i<arr.length;i++)
			sum+=arr[i];
		 return sum/arr.length;

	}

}
