package Arrays;

import java.util.Scanner;

public class UniqueElements {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the size");
		int size = sc.nextInt();

		int arr[] = new int[size];
		System.out.println("Enter the elements");

		for (int i = 0; i < size; i++)
			arr[i] = sc.nextInt();

		unique(arr);

	}

	public static void unique(int arr[]) {
		int count = 0;
		System.out.println("Unique elements are");
		for (int i = 0; i < arr.length; i++) {
			count = 0;
			for (int j = 0; j < arr.length; j++) {
				if (arr[i] == arr[j])
					count++;
			}
			if (count == 1)
				System.out.println(arr[i]);
		}
	}

}
