package Arrays;

public class MaxOfEachRow {

	public static void main(String[] args) {

		int matrix[][] = { { 12, 23, 4 }, { 1, 7, 9 }, { 10, 5, 2 } };
		for (int i = 0; i < matrix.length; i++) {
			int max = 0;
			for (int j = 0; j < matrix[i].length; j++) {
				if (matrix[i][j] > max)
					max = matrix[i][j];
				System.out.print(matrix[i][j] + " ");

			}
			System.out.print("  Max is " + max);
			System.out.println();
		}

	}

}
