package Arrays;

import java.util.Scanner;

public class IdentityMatrix {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no. of rows");
		int rows = sc.nextInt();
		System.out.println("Enter the no. of columns");
		int cols = sc.nextInt();

		int arr[][] = new int[10][10];
		System.out.println("Enter " + (rows * cols) + " Array elements");

		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++)
				arr[i][j] = sc.nextInt();
		}
		System.out.println("The Array is: ");
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++)
				System.out.println(arr[i][j] + " ");
			System.out.println();
		}
		int flag = 0;
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				if ((i == j && arr[i][j] != 1) || (i != j && arr[i][j] != 0)) {
					flag = 1;
					break;
				}
			}
		}
		if (flag == 1)
			System.out.println("The given matrix is not an Identity matrix");
		else
			System.out.println("The given matrix is  an Identity matrix");
	}
}