package Arrays;

public class SmallestAndSecondSmallest {

	public static void main(String[] args) {
		int arr[] = { 5, 7, 9, 54, 1, 3 };
		SumArray(arr);

	}

	public static void SumArray(int arr[]) {
		int first, second, sum = 0;
		first = second = Integer.MAX_VALUE;

		for (int i = 0; i < arr.length; i++) {
			if (arr[i] < first) {
				second = first;
				first = arr[i];
			} else if (arr[i] != first && arr[i] < second) {
				second = arr[i];
			}
		}
		if (second == Integer.MAX_VALUE)
			System.out.println("No second least element");
		else
			System.out.println("First Element :" + first + " \nSecond Element is: " + second);
		sum += first + second;
		System.out.println("Sum of smallest and second smallest is: " + sum);

	}
}
