package Arrays;

public class Array1 {

	public static void main(String[] args) {
		int arr[] = { 75, 85, 83, 67, 90 };
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
			sum = sum + arr[i];
		}
		System.out.println("Total sum: " + sum);
		char a[] = { 'a', 'b', 'c', 'd', 'e' };
		for (int i = 0; i < a.length; i++)
			System.out.println(a[i]);
	}

}
