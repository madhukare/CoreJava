package Arrays;

import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {
		int arr[] = { 12, 23, 45, 9, 8 };
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the element");
		int num = sc.nextInt();
		Search(arr, num);
	}

	public static void Search(int arr[], int num) {
		int flag = 0;
		for (int i = 0; i < arr.length; i++) {
			if (num == arr[i])
				flag = 1;
		}
		if (flag == 1)
			System.out.println("Element is found");
		else
			System.out.println("Element not found");

	}
}
