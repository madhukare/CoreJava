package Conditionals;

import java.util.Scanner;

public class TimeConverting {

	public static void main(String[] args) {
		int hours, minutes, seconds, addsec;
		Scanner sc = new Scanner(System.in);
		hours = sc.nextInt();
		minutes = sc.nextInt();
		seconds = sc.nextInt();
		addsec = sc.nextInt();
		AddSeconds(hours, minutes, seconds, addsec);
	}

	public static void AddSeconds(int hrs, int mins, int secs, int addsecs) {
		int totaltime = (hrs * 60 * 60) + (mins * 60) + secs + addsecs;
		hrs = totaltime / (60 * 60);
		int rem = totaltime % (60 * 60);
		mins = rem / 60;
		secs = rem % 60;
		System.out.println("Output time is: " + hrs + " hours " + mins + " minutes " + secs + " seconds");
	}
}
