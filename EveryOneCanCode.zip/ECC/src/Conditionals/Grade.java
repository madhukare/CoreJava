package Conditionals;

import java.util.Scanner;

public class Grade {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int sub1 = sc.nextInt();
		int sub2 = sc.nextInt();
		int sub3 = sc.nextInt();
		System.out.println(Percentage(sub1, sub2, sub3));
		System.out.println(CalcGrade(Percentage(sub1, sub2, sub3)));
	}

	public static double Percentage(int s1, int s2, int s3) {
		double per = ((s1 + s2 + s3) / 300.0) * 100;
		return per;
	}

	public static String CalcGrade(double percentage) {
		String grade = "";

		if (percentage >= 90)
			grade = "A";
		else if (percentage >= 70)
			grade = "B";
		else if (percentage >= 50)
			grade = "C";
		else
			grade = "F";

		return grade;

	}
}
