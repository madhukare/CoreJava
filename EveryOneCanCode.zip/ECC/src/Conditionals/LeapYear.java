package Conditionals;

import java.util.Scanner;

public class LeapYear {

	public static void main(String[] args) {
		int year;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a year");
		year = sc.nextInt();
		leapYear(year);

	}

	public static void leapYear(int y) {
		if (y % 400 == 0) {
			System.out.println("Century Leap year");
		} else if (y % 4 == 0 && y % 100 != 0) {
			System.out.println("Non Century Leap year");
		} else
			System.out.println("Not a leap year");
	}
}
