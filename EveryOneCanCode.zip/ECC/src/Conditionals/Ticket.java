package Conditionals;

import java.util.Scanner;

public class Ticket {

	public static void main(String[] args) {
		int a, b, c;
		Scanner sc = new Scanner(System.in);
		a = sc.nextInt();
		b = sc.nextInt();
		c = sc.nextInt();
		result(a, b, c);
	}

	public static void result(int num1, int num2, int num3) {
		if (num1 != num2 && num1 != num3 && num2 != num3) {
			System.out.println("0");
		} else if (num1 == num2 && num2 != num3 || num1 == num3 && num3 != num2) {
			System.out.println("10");
		} else {
			System.out.println("20");
		}
	}

}
