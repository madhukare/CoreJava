package Conditionals;

import java.util.Scanner;

public class Fivedigitnumber {

	public static void main(String[] args) {
		int num;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a number");
		num = sc.nextInt();
		boolean result = isFiveDigit(num);
		if (result == true) {
			System.out.println(num + " is 5 digit number");
		} else {
			System.out.println(num + " is not a 5 digit number");
		}
	}

	public static boolean isFiveDigit(int n) {
		if (n > 9999 && n < 99999) {
			return true;
		} else {
			return false;
		}
	}

}