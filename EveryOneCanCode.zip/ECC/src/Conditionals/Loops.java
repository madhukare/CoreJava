package Conditionals;

import java.util.Scanner;

public class Loops {

	public static void main(String[] args) {
		int age;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter your age");
		age = sc.nextInt();
		if (age > 90) {
			System.out.println("Your age is greater than 90");
		} else if (age < 90 && age >= 50) {
			System.out.println("your age lies between 50 and 90");
		} else {
			System.out.println("your age is less than 50");
		}
	}

}
