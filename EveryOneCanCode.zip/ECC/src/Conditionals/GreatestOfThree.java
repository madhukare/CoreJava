package Conditionals;

import java.util.Scanner;

public class GreatestOfThree {

	public static void main(String[] args) {
		int num1, num2, num3;
		Scanner sc = new Scanner(System.in);
		// System.out.println("Enter 3 numbers");
		num1 = sc.nextInt();
		num2 = sc.nextInt();
		num3 = sc.nextInt();
		greatestof3(num1, num2, num3);

	}

	public static void greatestof3(int n1, int n2, int n3) {
		if (n1 > n2) {
			if (n1 > n3) {
				System.out.println(n1 + " is greatest number");
			} else {
				System.out.println(n3 + " is greatest number");
			}
		} else if (n2 > n3) {
			System.out.println(n2 + " is greatest number");
		} else
			System.out.println(n3 + " is greatest number");
	}
}
