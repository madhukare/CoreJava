package Conditionals;

import java.util.Scanner;

public class SellingPrice {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int costprice = sc.nextInt();
		System.out.println(calcSellingPrice(costprice));

	}

	public static double calcSellingPrice(int cp) {
		if (cp > 0 && cp <= 10000) {
			double discount = (cp * 10) / 100.0;
			double sp = (cp - discount);
			return sp;
		} else if (cp > 10000 && cp <= 20000) {
			double discount = (cp * 20) / 100.0;
			double sp = (cp - discount);
			return sp;
		} else {
			double discount = (cp * 25) / 100.0;
			double sp = (cp - discount);
			return sp;
		}

	}
}
