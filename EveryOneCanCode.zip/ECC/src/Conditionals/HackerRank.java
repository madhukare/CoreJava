package Conditionals;

import java.util.Scanner;

public class HackerRank {

	public static void main(String[] args) {
		int num;
		Scanner sc = new Scanner(System.in);
		num = sc.nextInt();
		isEvenOdd(num);

	}

	public static void isEvenOdd(int n) {
		if (n % 2 != 0) {
			System.out.println("Weird");
		} else if (n >= 2 && n <= 5) {
			System.out.println("Not Weird");
		} else if (n >= 6 && n <= 20) {
			System.out.println("Weird");
		} else if (n > 20) {
			System.out.println("Not Weird");
		}
	}
}
